package app.exercise.algebra;

interface Arithmetic {
    void add(Rational operand);
    void sub(Rational operand);
    void mul(Rational operand);
    void div(Rational operand);
}
