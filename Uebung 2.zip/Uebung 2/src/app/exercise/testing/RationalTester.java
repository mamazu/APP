package app.exercise.testing;


import app.exercise.algebra.Rational;

public class RationalTester {
    public static void main(String[] args) {
        Rational r = new Rational(2, -4);
        System.out.println(r.toString());
    }
}
